## ---- echo = FALSE, message = FALSE--------------------------------------
knitr::opts_chunk$set(collapse = T, comment = "#>")
library(binomial)
library(ggplot2)

## ------------------------------------------------------------------------
bv<-bin_variable(trials=10,prob=0.5)

## ------------------------------------------------------------------------
bv
summary(bv)

## ------------------------------------------------------------------------
bin_distribution(trials=10,prob=0.5)
bin_cumulative(trials=10,prob=0.5)

## ------------------------------------------------------------------------
plot(bin_distribution(trials=10,prob=0.5))
plot(bin_cumulative(trials=10,prob=0.5))

## ------------------------------------------------------------------------
bin_choose(5,1)
bin_mean(5,0.5)
bin_variance(5,0.5)
bin_mode(5,0.5)
bin_skewness(5,0.5)
bin_kurtosis(5,0.5)

