#import packages
#' @import ggplot2
#' @name binomial
#' @docType package
NULL
